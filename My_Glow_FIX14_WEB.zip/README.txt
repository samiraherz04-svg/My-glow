My Glow FIX 14 — Web package 💕
The main app file is index.html so standard hosting opens it automatically.
Keep the icons folder and manifest.json next to index.html.
